from django.urls import path
from . import views
from .views import user_reservations
from .views import dashboard



urlpatterns = [
    path('register_user/', views.register_user, name='register_user'), 
    path('choose-registration/', views.choose_registration_type, name='choose_registration_type'),
    path('my-reservations/',user_reservations,name='user_reservations'),
    path('dashboard/',dashboard,name='dashboard')
]