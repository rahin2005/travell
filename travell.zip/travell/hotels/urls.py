# urls.py in hotels folder

from django.urls import path
from . import views
from .views import register_hotel
from django.urls import path
from .views import register_hotel, add_hotel_by_admin
from .views import hotel_detail
from .views import hotel_detail, reserve_room, reservation_success
from hotels.views import home




urlpatterns = [
    path('register-hotel/', views.register_hotel, name='register_hotel'),
    path('register/', views.register_hotel, name='hotel_register'),  
    path('add/', views.add_hotel_by_admin, name='add_hotel_by_admin'),  
    path('hotels/hotel/detail/<int:hotel_id>/', views.hotel_detail, name='hotel_detail'),  # مسیر صحیح برای جزئیات هتل
    path('hotel/edit/<int:hotel_id>/', views.edit_hotel, name='edit_hotel'),
    path('hotel/add_room/<int:hotel_id>/', views.add_room, name='add_room'),
    path('reserve/<int:room_id>/', views.reserve_room, name='reserve_room'),
    path('reservation-success/', views.reservation_success, name='reservation_success'),
    path('', views.home, name='home'),
    
]