from django import forms
from .models import Hotel
from .models import HotelImage
from django.forms import modelformset_factory


class HotelRegistrationForm(forms.ModelForm):
    class Meta:
        model = Hotel
        fields = ['name', 'address', 'manager_name', 'manager_phone','hotel_phone', 'bank_number','features', 'password']
        widgets = {
            'password': forms.PasswordInput(),
            'features': forms.Textarea(attrs={'rows': 4, 'placeholder': 'امکانات و ویژگی‌های هتل را وارد کنید...'}),
        }

class HotelImageForm(forms.ModelForm):
    class Meta:
        model = HotelImage
        fields = ['image', 'description']  # فیلدهای مورد نظر برای فرم

# ایجاد فرم برای مجموعه‌ای از تصاویر هتل
HotelImageFormSet = modelformset_factory(HotelImage, form=HotelImageForm, extra=20)  # extra=10 یعنی 10 فرم اضافی


from django import forms
from .models import Reservation

class ReservationForm(forms.ModelForm):
    class Meta:
        model = Reservation
        fields = ['check_in', 'check_out']
        widgets = {
            'check_in': forms.DateInput(attrs={'type': 'date'}),
            'check_out': forms.DateInput(attrs={'type': 'date'}),
        }
        


        # forms.py
from django import forms
from .models import Hotel, Room

class HotelForm(forms.ModelForm):
    class Meta:
        model = Hotel
        fields =['name','address','city','manager_name','manager_phone','hotel_phone','bank_number','features','stars','password']

        widgets = {
            'stars': forms.RadioSelect(choices=Hotel.STAR_CHOICES)  # نمایش ستاره‌ها به‌صورت دکمه‌های انتخابی
        }


# forms.py
class RoomForm(forms.ModelForm):
    class Meta:
        model = Room
        fields = ['hotel','name','capacity','features','available']  # فیلدهای اتاق



from django import forms

class HotelSearchForm(forms.Form):
    name = forms.CharField(required=False, label='نام هتل')
    city = forms.CharField(required=False, label='نام شهر')