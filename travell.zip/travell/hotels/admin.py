from django.contrib import admin
from .models import Hotel, Room, Reservation, HotelImage

# افزودن تصاویر هتل در صفحه مدیریت
class HotelImageInline(admin.TabularInline):  # یا admin.StackedInline برای نمایش متفاوت
    model = HotelImage
    extra = 10  # تعداد فرم‌های خالی اضافی

# افزودن اتاق‌ها در صفحه مدیریت هتل
class RoomInline(admin.TabularInline):  
    model = Room
    extra = 1  

# تنظیمات مدیریت هتل
@admin.register(Hotel)
class HotelAdmin(admin.ModelAdmin):
    list_display = ['name','city', 'address', 'manager_name', 'manager_phone', 'hotel_phone', 'bank_number', 'features']
    inlines = [HotelImageInline, RoomInline]  # نمایش تصاویر و اتاق‌ها در صفحه هتل

# تنظیمات مدیریت اتاق‌ها
@admin.register(Room)
class RoomAdmin(admin.ModelAdmin):
    list_display = ['name', 'hotel', 'price', 'capacity', 'available']
    list_filter = ['hotel', 'available']
    search_fields = ['name', 'hotel__name']

# تنظیمات مدیریت رزروها
@admin.register(Reservation)
class ReservationAdmin(admin.ModelAdmin):
    list_display = ['user', 'room', 'check_in', 'check_out', 'total_price']
    list_filter = ['room', 'check_in']
    search_fields = ['user__username', 'room__name']

# ثبت مدل HotelImage جداگانه در صورت نیاز
@admin.register(HotelImage)
class HotelImageAdmin(admin.ModelAdmin):
    list_display = ['hotel', 'image']



