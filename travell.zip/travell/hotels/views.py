from django.shortcuts import render, redirect
from hotels.forms import HotelRegistrationForm, HotelImageFormSet
from .models import Hotel
from django.shortcuts import render, get_object_or_404
from .models import Hotel,Room
from .forms import HotelForm
from .forms import HotelForm, HotelImageForm
from .models import Hotel, HotelImage
from django.forms import modelformset_factory

def register_hotel(request):
    HotelImageFormSet = modelformset_factory(HotelImage, form=HotelImageForm, extra=20)  # extra=1 برای اضافه کردن یک فرم جدید

    if request.method == 'POST':
        form = HotelForm(request.POST)
        formset = HotelImageFormSet(request.POST, request.FILES)
        if form.is_valid() and formset.is_valid():
            hotel = form.save()  # هتل جدید ذخیره می‌شود
            for form in formset:
                if form.cleaned_data:
                    image = form.cleaned_data.get('image')
                    if image:
                        HotelImage.objects.create(hotel=hotel, image=image)  # تصویر هتل ذخیره می‌شود
            return redirect('hotel_detail', hotel_id=hotel.id)  # تغییر مسیر به صفحه جزئیات هتل
    else:
        form = HotelForm()
        formset = HotelImageFormSet(queryset=HotelImage.objects.none())  # فرم خالی برای آپلود تصاویر

    return render(request, 'hotels/register_hotel.html', {'form': form, 'formset': formset})


    


from django.shortcuts import render, redirect
from .forms import HotelRegistrationForm
from django.contrib.auth.decorators import login_required, user_passes_test

# تابعی که چک کنه فقط مدیر بتونه این صفحه رو ببینه
def is_admin(user):
    return user.is_superuser  # فقط ادمین‌ها دسترسی داشته باشند

@login_required
@user_passes_test(is_admin)
def add_hotel_by_admin(request):
    if request.method == 'POST':
        form = HotelRegistrationForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('home')  # بعد از ثبت، به صفحه اصلی منتقل می‌شه
    else:
        form = HotelRegistrationForm()
    return render(request, 'hotels/add_hotel.html', {'form': form})



def hotel_detail(request, hotel_id):
    hotel = get_object_or_404(Hotel, pk=hotel_id)
    rooms = Room.objects.filter(hotel=hotel)
    images = HotelImage.objects.filter(hotel=hotel)
    
    # اضافه کردن پرینت‌های دیباگ
    print('Hotel details:', {
        'id': hotel.id,
        'name': hotel.name,
        'room_count': rooms.count(),
        'image_count': images.count()
    })
    
    return render(request, 'hotels/hotel_detail.html', {
        'hotel': hotel,
        'rooms': rooms,
        'images': images
    })



from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from .models import Room, Reservation
from .forms import ReservationForm

@login_required
def reserve_room(request, room_id):
    room = get_object_or_404(Room, id=room_id)

    if request.method == 'POST':
        form = ReservationForm(request.POST)
        if form.is_valid():
            reservation = form.save(commit=False)
            reservation.user = request.user  # کاربر لاگین‌شده رو اضافه می‌کنیم
            reservation.room = room
            # محاسبه قیمت کل (تعداد شب‌ها * قیمت هر شب)
            days = (reservation.check_out - reservation.check_in).days
            reservation.total_price = days * room.price
            reservation.save()
            return redirect('reservation_success')  # هدایت به صفحه تأیید رزرو

    else:
        form = ReservationForm()

    return render(request, 'hotels/reserve_room.html', {'form': form, 'room': room})

def reservation_success(request):
    return render(request, 'hotels/reservation_success.html')



# views.py
from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from .forms import HotelForm
from .models import Hotel

@login_required
def edit_hotel(request, hotel_id):
    hotel = Hotel.objects.get(id=hotel_id, owner=request.user)  # پیدا کردن هتل متعلق به کاربر
    if request.method == 'POST':
        form = HotelForm(request.POST, instance=hotel)
        if form.is_valid():
            form.save()
            return redirect('hotel_detail', hotel_id=hotel.id)  # به صفحه جزئیات هتل بعد از ذخیره هدایت می‌کند
    else:
        form = HotelForm(instance=hotel)
    return render(request, 'hotels/edit_hotel.html', {'form': form})


# views.py
from .forms import RoomForm
from .models import Hotel

@login_required
def add_room(request, hotel_id):
    hotel = Hotel.objects.get(id=hotel_id, owner=request.user)  # پیدا کردن هتل متعلق به کاربر
    if request.method == 'POST':
        form = RoomForm(request.POST)
        if form.is_valid():
            room = form.save(commit=False)
            room.hotel = hotel  # ربط دادن اتاق به هتل
            room.save()
            return redirect('hotel_detail', hotel_id=hotel.id)  # هدایت به صفحه جزئیات هتل
    else:
        form = RoomForm()
    return render(request, 'hotels/add_room.html', {'form': form, 'hotel': hotel})





# views.py
from django.shortcuts import get_object_or_404, render
from .models import Hotel, Room, HotelImage

def hotel_detail(request, hotel_id):
    hotel = get_object_or_404(Hotel, pk=hotel_id)
    rooms = Room.objects.filter(hotel=hotel)
    images = HotelImage.objects.filter(hotel=hotel)
    print('ok0', rooms)
    print('ok0', images)

    

    return render(request, 'hotels/hotel_detail.html', {
        'hotel': hotel,
        'rooms': rooms,
        'images': images
    })





from django.shortcuts import render
from .forms import HotelSearchForm
from .models import Hotel

def home(request):
    hotels = Hotel.objects.all()  # در ابتدا همه هتل‌ها رو می‌گیریم
    form = HotelSearchForm(request.GET)  # گرفتن اطلاعات فرم از درخواست GET

    if form.is_valid():
        name = form.cleaned_data.get('name')  # گرفتن نام هتل از فرم
        city = form.cleaned_data.get('city')  # گرفتن شهر از فرم

        # فیلتر کردن بر اساس نام
        if name:
            hotels = hotels.filter(name__icontains=name)  # نام هتل‌ها رو جستجو می‌کنیم

        # فیلتر کردن بر اساس شهر
        if city:
            hotels = hotels.filter(city__icontains=city)  # شهر هتل‌ها رو جستجو می‌کنیم

    # ارسال فرم و هتل‌های فیلتر شده به قالب
    context = {
        'form': form,
        'hotels': hotels
    }
    return render(request, 'home.html', context)


