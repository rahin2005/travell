from django.urls import path
from . import views

urlpatterns = [
    path('hotel/<int:hotel_id>/', views.hotel_detail, name='hotel_detail'),
    path('hotel/<int:hotel_id>/edit/', views.edit_hotel, name='edit_hotel'),
    path('hotel/<int:hotel_id>/add-room/', views.add_room, name='add_room'),
] 