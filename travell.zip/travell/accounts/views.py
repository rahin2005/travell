from django.shortcuts import render

# Create your views here.
# views.py in accounts folder

from django.shortcuts import render, redirect
from .forms import UserRegistrationForm

def register_user(request):
    if request.method == 'POST':
        form = UserRegistrationForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('home')  # به صفحه اصلی هدایت بشه
    else:
        form = UserRegistrationForm()
    return render(request, 'accounts/register_user.html', {'form': form})


def choose_registration_type(request):
    return render(request, 'accounts/choose_registration_type.html')

from django.shortcuts import render

def choose_registration_type(request):
    return render(request, 'home/home.html')  # مسیر دقیق home.html


from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from hotels.models import Reservation

@login_required
def user_reservations(request):
    reservations = Reservation.objects.filter(user=request.user)
    return render(request, "account/user_reservations.html", {"reservations": reservations})


from django.shortcuts import render
from django.contrib.auth.decorators import login_required

@login_required
def dashboard(request):
    return render(request, "account/dashboard.html")